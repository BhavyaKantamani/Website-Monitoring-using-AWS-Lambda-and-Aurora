import json
import base64
import boto3
import pymysql
from datetime import datetime, timedelta
import decimal
import os

# Fetch values from environment variables
REGION = os.getenv("AWS_REGION", "us-east-2")
HOST = os.getenv("RDS_HOST")
USER = os.getenv("RDS_USER", "admin")
PASSWORD = os.getenv("RDS_PASSWORD") 
DB_NAME = os.getenv("RDS_DB_NAME", "logs")
SNS_TOPIC_ARN = os.getenv("SNS_TOPIC_ARN")


sns_client = boto3.client('sns', region_name=REGION)
dynamodb = boto3.resource('dynamodb', region_name=REGION)
table = dynamodb.Table('website-monitoring-records')


conn = pymysql.connect(host=HOST, user=USER, passwd=PASSWORD, db=DB_NAME, connect_timeout=5)

def check_invoice_frequency(customer_id, current_time):
    twenty_seconds_ago = current_time - timedelta(seconds=20)
    response = table.scan(
        FilterExpression="CustomerID = :cid and OrderDate >= :ts",
        ExpressionAttributeValues={
            ":cid": decimal.Decimal(customer_id),
            ":ts": twenty_seconds_ago.isoformat()
        }
    )
    unique_invoices = {item['OrderID'].split("-")[0] for item in response['Items']}
    return len(unique_invoices)

def check_last_alert_time(customer_id):
    five_minutes_ago = datetime.now() - timedelta(minutes=2)
    with conn.cursor() as cur:
        cur.execute("SELECT COUNT(*) FROM logs_history WHERE CustomerID = %s AND alarm_creation_time >= %s", (customer_id, five_minutes_ago.strftime('%Y-%m-%d %H:%M:%S')))
        result = cur.fetchone()
        if result and result[0] > 0:
            return True
        else:
            return False
def safe_decimal(value, default=0):
    """Convert value to Decimal safely, returning a default if conversion fails."""
    try:
        return decimal.Decimal(str(value).strip())  # Strip spaces and convert to string first
    except (ValueError, TypeError, decimal.InvalidOperation):
        print(f"Warning: Unable to convert {value} to Decimal. Using default: {default}")
        return decimal.Decimal(default)

def lambda_handler(event, context):
    output = []
    current_time = datetime.now()

    for record in event['records']:
        try:
            # Decode Base64 data
            decoded_data = base64.b64decode(record['data']).decode('utf-8')
            payload = json.loads(decoded_data)
            print(payload)

            # Convert numeric fields safely
            customer_id = safe_decimal(payload.get('Customer'))
            quantity = safe_decimal(payload.get('Quantity'))
            unit_price = safe_decimal(payload.get('UnitPrice'))

            # Skip processing if CustomerID is missing
            if customer_id == 0:
                print(f"Skipping record due to invalid CustomerID: {payload.get('Customer')}")
                continue

            # Construct DynamoDB item
            item = {
                'CustomerID': customer_id,
                'OrderID': f"{payload['InvoiceNo']}-{payload['StockCode']}",
                'OrderDate': current_time.isoformat(),
                'Quantity': quantity,
                'UnitPrice': unit_price,
                'Description': payload.get('Description', 'N/A'),
                'Country': payload.get('Country', '').strip()
            }

            # Insert into DynamoDB
            table.put_item(Item=item)
            print(f"Inserted into DynamoDB: {item}")

            # Check for high-frequency invoices
            num_unique_invoices = check_invoice_frequency(customer_id, current_time)
            if num_unique_invoices > 5 and not check_last_alert_time(customer_id):
                message = f"High invoice frequency detected for Customer {customer_id}. Number of unique invoices: {num_unique_invoices}"
                
                try:
                    sns_client.publish(TopicArn=SNS_TOPIC_ARN, Message=message, Subject='High Invoice Alert')
                    print(f"SNS Notification sent: {message}")
                except Exception as e:
                    print(f"Failed to send SNS notification: {e}")

                # Log alert in Aurora MySQL
                with conn.cursor() as cur:
                    cur.execute(
                        'INSERT INTO logs_history (alarm_creation_time, CustomerID, Number_of_invoice) VALUES (%s, %s, %s)',
                        (current_time.strftime('%Y-%m-%d %H:%M:%S'), customer_id, num_unique_invoices)
                    )
                    conn.commit()
                    print("Inserted into Aurora MySQL")

            # Prepare response for Kinesis
            output_record = {
                'recordId': record['recordId'],
                'result': 'Ok',
                'data': record['data']  
            }
            output.append(output_record)

        except Exception as e:
            print(f"Error processing record: {e}")
            output_record = {
                'recordId': record['recordId'],
                'result': 'ProcessingFailed',
                'data': record['data']
            }
            output.append(output_record)

    return {'records': output}